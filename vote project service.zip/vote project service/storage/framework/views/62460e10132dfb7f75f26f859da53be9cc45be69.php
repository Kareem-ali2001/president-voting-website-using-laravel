<button class="btn btn-danger ml-3" wire:click='logout'>Logout</button>
<?php /**PATH C:\Users\DELL\vote project service\resources\views/livewire/frontend/logout.blade.php ENDPATH**/ ?>