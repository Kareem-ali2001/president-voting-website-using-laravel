<div>
     <?php $__env->slot('title', null, []); ?> 
        Logout
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('image_title', null, []); ?> 
            Logout
             <?php $__env->endSlot(); ?>

            <div class="contianer">
                <div class="row d-flex justify-content-center">
                    <div class="col-xl-5 col-lg-5 col-sm-12">
                        <div class="my-5">
                            <div class="card">
                                <div class="card-body">
                                    <h3>See you in next Eelection</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
<?php /**PATH C:\Users\DELL\vote project service\resources\views/livewire/frontend/logout-page.blade.php ENDPATH**/ ?>