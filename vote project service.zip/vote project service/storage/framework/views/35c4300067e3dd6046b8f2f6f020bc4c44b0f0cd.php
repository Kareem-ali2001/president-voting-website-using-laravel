<a href="" class="btn btn-danger w-100" wire:click.prevent='logout'>Logout</a>
<?php /**PATH C:\Users\DELL\vote project service\resources\views/livewire/admin/logout.blade.php ENDPATH**/ ?>