<a href="" class="btn btn-danger w-100" wire:click.prevent='logout'>Logout</a>
