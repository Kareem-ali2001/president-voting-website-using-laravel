<button class="btn btn-danger ml-3" wire:click='logout'>Logout</button>
